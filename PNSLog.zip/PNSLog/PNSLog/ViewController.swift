//
//  ViewController.swift
//  PNSLog
//
//  Created by Apple on 2017/2/10.
//  Copyright © 2017年 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       NJLog(456)
    }
}

